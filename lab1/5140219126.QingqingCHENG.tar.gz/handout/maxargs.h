#ifndef MAXARGS_H
#define MAXARGS_H

#include "slp.h"


/*
 * Return the maximum number of arguments of any print
 * statement within any subexperssion of a given statement
 */
int maxargs(A_stm stm);

/*
 * Return the maximum between a and b
 */
int max(int a,int b);

/*
 * Return the number of items in an expList
 */
int count_exps(A_expList exps);

/*
 * Return the maximum number of arguments of any print
 * statement within any subexperssion of a given expression
 */
int maxargs_exp(A_exp exp);

/*
 * Return the maximum number of arguments of any print
 * statement within any subexperssion of a given expression list
 */
int maxargs_expList(A_expList exps);

#endif /* MAXARGS_H */
