#ifndef INTERP_H
#define INTERP_H

#include <stdlib.h>
#include "util.h"

/*
 * "Interpret" a program in this language.
 */
void interp(A_stm stm);

/*
 * table:
 * Mapping identifiers to the interger values assigned th them,
 * as a list of id * int pairs
 */
typedef struct table *Table_;
struct table {
  string id;
  int value;
  Table_ tail;
};
Table_ Table(string id, int value, struct table *tail);

/*
 * Produce a new table from the specified table. The new table is just like
 * the original one except that some identifiers map to different integers as
 * a result of the given statement.
 */
Table_ interpStm(A_stm s, Table_ t);

typedef struct intAndTable *IntAndTable_;
struct intAndTable {
  int i;
  Table_ t;
};
IntAndTable_ IntAndTable(int i, Table_ t);

/*
 * The result of interpreting an expression e1 with table t1 is an integer
 * value i and a new table t2.  When interpreting an expression with two
 * subexpressions (such as an OpExp), the table t2 resulting from the first
 * subexpression can be used in processing the second subexpression.
 */
IntAndTable_ interpExp(A_exp e, Table_ t);

/*
 * The result of interpreting an expression list e1 with table t1 is an integer
 * value i and a new table t2.  When interpreting an expression list with one
 * subexpressions (such as an OpExp) and another subexpression list,
 * the table t2 resulting from the first subexpression can be
 * used in processing the second subexpression list.
 */
IntAndTable_ interpExpList(A_expList expList, Table_ t);

/*
 * Put a new element at the head of the linked list.
 */
Table_ update(Table_ t, string id, int value);

/*
 * Search down the linked list.
 */
int lookup(Table_ t, string key);

#endif /* INTERP_H */
